<?php
session_start();

if(!isset($_SESSION['id']) || $_SESSION['expire'] < time()) {
	header("location: index.php");
} 
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>cerTracker | Dashboard</title>
	<!-- Tell the browser to be responsive to screen width -->
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<!-- Bootstrap 3.3.5 -->
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<!-- Font Awesome -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
	<!-- Ionicons -->
	<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
	<!-- DataTables -->
	<link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
	<!-- Theme style -->
	<link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
    folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="dist/css/toastr.min.css">
    <link rel="stylesheet" href="dist/css/jquery-confirm.min.css">
    <link rel="icon" type="image/ico" href="dist/img/favicon.ico">

    
</head>
<body class="hold-transition skin-blue sidebar-mini">
	<div class="wrapper">

		<header class="main-header">
			<!-- Logo -->
			<a class="logo">
				<!-- mini logo for sidebar mini 50x50 pixels -->
				<span class="logo-mini"><b>C</b></span>
				<!-- logo for regular state and mobile devices -->
				<span class="logo-lg">cerTracker</span>
			</a>
			<!-- Header Navbar: style can be found in header.less -->
			<nav class="navbar navbar-static-top" role="navigation">
				<!-- Sidebar toggle button-->
				<a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
				<div class="navbar-custom-menu">
				</div>
			</nav>
		</header>

		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper" id="mainDiv">
			<!-- Content Header (Page header) -->
			<section class="content-header">
				<h1>Add Domain<small>| cerTracker</small></h1>
			</section>


			<!-- Left side column. contains the logo and sidebar -->
			<aside class="main-sidebar">
				<!-- sidebar: style can be found in sidebar.less -->
				<section class="sidebar">
					<!-- sidebar menu: : style can be found in sidebar.less -->
					<ul class="sidebar-menu">
						<li class="header">Welcome back, <?php echo $_SESSION['name'];?>!</li>
						

						
					</ul>
				</section>
				<!-- /.sidebar -->
			</aside>





			<!-- Main content -->
			<section class="content" id="hitsSection">
				<div class="row">
					<div class="col-xs-12">
						<div class="box">
							<div class="box-body">
								<div class="box box-info">
									<div class="box-header with-border">

									</div>
									<!-- /.box-header -->
									<!-- form start -->



									
									<form class="form-horizontal">
										<div class="box-body">
											<div class="form-group">
												<label for="inputDomain" class="col-sm-2 control-label">Domain</label>

												<div class="col-sm-10">
													<input class="form-control" id="domain" placeholder="domain.com" type="text" name="domain">
												</div>
											</div>
											<div class="form-group">
												<label for="inputPort" class="col-sm-2 control-label">Port</label>

												<div class="col-sm-10">

													<input class="form-control"  type="number" id="port" min="1" max="65535" name="port">

												</div>
											</div>

										</div>
										<!-- /.box-body -->
										<div class="box-footer">

											<button type="button" id="submitBTN" class="btn btn-info pull-right">Submit</button>
										</div>
										<!-- /.box-footer -->
									</form>










								</div>
							</div><!-- /.box-body -->
						</div><!-- /.box -->

						<button type="button" class="btn btn-primary pull-left" id="backBTN"><i class="fa fa-caret-left"></i>  Back</button>
					</div><!-- /.col -->
				</div><!-- /.row -->
			</section><!-- /.content -->
		</div><!-- /.content-wrapper -->


		<footer class="main-footer">
			<div class="pull-right hidden-xs">
				<b>Version</b> 2.3.8
			</div>
			<strong>Copyright &copy; 2014-2016 <a href="http://almsaeedstudio.com">Almsaeed Studio</a>.</strong> All rights
			reserved.
		</footer>

		<!-- jQuery 2.2.3 -->
		<script src="../../plugins/jQuery/jquery-2.2.3.min.js"></script>
		<!-- Bootstrap 3.3.6 -->
		<script src="../../bootstrap/js/bootstrap.min.js"></script>
		<!-- SlimScroll -->
		<script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
		<!-- FastClick -->
		<script src="../../plugins/fastclick/fastclick.js"></script>
		<!-- AdminLTE App -->
		<script src="../../dist/js/app.min.js"></script>
		<!-- AdminLTE for demo purposes -->
		<script src="dist/js/demo.js"></script>
		<script src="dist/js/jquery-confirm.min.js"></script>

		<script src="dist/js/login.js"></script>
		<script src="dist/js/domain.js"></script>
		<script src="dist/js/util.js"></script>
		<script src="dist/js/logout.js"></script>
		<script src="dist/js/toastr.min.js"></script>
	</body>
	</html>
