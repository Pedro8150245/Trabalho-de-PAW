-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 20, 2017 at 12:59 AM
-- Server version: 5.7.18-0ubuntu0.16.04.1
-- PHP Version: 7.0.18-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `certracker`
--

-- --------------------------------------------------------

--
-- Table structure for table `Alerts`
--

CREATE TABLE `Alerts` (
  `id` int(13) NOT NULL,
  `domains_id` int(11) NOT NULL,
  `num_days` int(11) NOT NULL,
  `message` varchar(300) NOT NULL,
  `alert_emails` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Alerts`
--

INSERT INTO `Alerts` (`id`, `domains_id`, `num_days`, `message`, `alert_emails`) VALUES
(31, 185, 12, 'Test', 'admin@gmail.com'),
(33, 185, 51, 'test msg', 'test@gmail.com,admin@gmail.com'),
(34, 186, 1, 'Urgent Message', 'urgent@facebook.com');

-- --------------------------------------------------------

--
-- Table structure for table `Domains`
--

CREATE TABLE `Domains` (
  `id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `domain` varchar(300) NOT NULL,
  `port` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Domains`
--

INSERT INTO `Domains` (`id`, `users_id`, `domain`, `port`) VALUES
(185, 25, 'google.com', 123),
(186, 25, 'www.facebook.com', 21);

-- --------------------------------------------------------

--
-- Table structure for table `Monitoring_Results`
--

CREATE TABLE `Monitoring_Results` (
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `domains_id` int(11) NOT NULL,
  `days_left` int(11) DEFAULT NULL,
  `server_address` varchar(45) DEFAULT NULL,
  `trusted_status` varchar(15) DEFAULT NULL,
  `site_status` varchar(15) DEFAULT NULL,
  `chain_hash` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `timestamp` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP
) ;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`id`, `email`, `password`, `timestamp`) VALUES
(25, 'user1@gmail.com', 'b49d4d6df14794fcac11d6189b8c4bd3bcbc5adf986b76c4a7e2ca27d3e36c50', '2017-06-19 15:32:13.861452');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Alerts`
--
ALTER TABLE `Alerts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Domains`
--
ALTER TABLE `Domains`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_id` (`users_id`);

--
-- Indexes for table `Monitoring_Results`
--
ALTER TABLE `Monitoring_Results`
  ADD PRIMARY KEY (`timestamp`),
  ADD KEY `domains_id` (`domains_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Alerts`
--
ALTER TABLE `Alerts`
  MODIFY `id` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `Domains`
--
ALTER TABLE `Domains`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=187;
--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `Domains`
--
ALTER TABLE `Domains`
  ADD CONSTRAINT `Domains_ibfk_1` FOREIGN KEY (`users_id`) REFERENCES `Users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `Monitoring_Results`
--
ALTER TABLE `Monitoring_Results`
  ADD CONSTRAINT `Monitoring_Results_ibfk_1` FOREIGN KEY (`domains_id`) REFERENCES `Domains` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
